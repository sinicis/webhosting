<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
require_once('../functions.php');
?>

<html lang="de">
<head>
    <style media="screen" type="text/css">
        @import "../style/style.css";
    </style>

    <meta name="author" content="Simon Isenschmid" />
    <meta name='description' content='Ironsmith' />
    <meta http-equiv="Content-Type" content="text/html; charset=uft-8" />
    <meta name="keywords" content="Schweiz, Suisse, Swizzera, Switzerland, Verwaltung, Administration, Amministrazione, Administration, design, logo, image, identity" />
</head>
<body>
<div class='allinone' id='allinone'>
	<h1 align='center'>ironsmith Websolutions</h1>

<div class='menu' id='menu'>
<? displayMenu(); ?>
</div>


	<h3>Herzlich Willkommen</h3>
	<p>
	Meine Website befindet sich zurzeit noch im Aufbau der Grundmauern. Gerne gebe ich Ihnen aber bereits jetzt Auskunft &uuml;ber meine Dienstleistungen.</br>
	Seien Sie nicht scheu und <a href='mailto:webhosting@ironsmith.ch'>kontaktieren Sie mich</a> jederzeit und unkompliziert.
	</p>
	<h4>Referenzen</h4>

	</br>
	<a target='_blank' href='http://www.schenk-bar.ch//'>Schenk-Bar, Hilterfingen</a></br>
	<a target='_blank' href='http://www.schlosser-stubenwagen.ch/'>Schlosser Stubenwagen</a></br>	
	<a target='_blank' href='http://www.barbara-gruetter.ch//'>Barbara Gr&uuml;tter</a></br>
	<a target='_blank' href='http://www.saurer-bau.ch/'>Saurer Bau GmBH Oberhofen</a></br>	
	<a target='_blank' href='http://www.stelladellago.ch/'>Ristorante Stella del Lago Oberhofen</a></br>	
	</br>
	
	<!-- <h4>Unterseiten</h4>
	<a href='http://www.ironsmith.ch/gifdump_01.php'>Hilarious Gifdump #1</a></br>
	<a href='http://www.ironsmith.ch/gifdump_02.php'>Hilarious Gifdump #2</a></br>-->
	<!-- <a href='http://www.ironsmith.ch/girlsdump.php'>B&uuml;zzus Giggerigmacher</a></br> -->
	</br>
	
</div>
<div class='cloud'></div>
<div class='footer'>ironsmith</div>
</body>
</html>
