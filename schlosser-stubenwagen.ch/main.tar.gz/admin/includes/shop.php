<?php
//phpinfo();
// alle Kategorien auslesen
$catId      = array();
$catName    = array();
$result     = getCategory();
$catCount   = $result->num_rows;

// displaying the points
while ($row = $result->fetch_assoc()) {
    array_push($catId,$row['id_cat']);
    array_push($catName,$row['category']);
}

// Title
echo "<h1>Shop-Verwaltung</h1>";
echo "<h2>Neuer Artikel erfassen</h2>";

$action = (!isset($_GET['action'])) ? "form" : $_GET['action'];

// Formular geschickt?
//
// HILFE: http://php.net/manual/de/features.file-upload.post-method.php
//
if ($action == "add") {


//header('Content-Type: text/plain; charset=utf-8');
/*
try {   
    // Undefined | Multiple Files | $_FILES Corruption Attack
    // If this request falls under any of them, treat it invalid.
    if (
        !isset($_FILES['userfile']['error']) ||
        is_array($_FILES['userfile']['error'])
    ) {
        echo "<pre>"; print_r($_FILES); echo "</pre>";
        throw new RuntimeException('Invalid parameters.');
    }

    // Check $_FILES['userfile']['error'] value.
    switch ($_FILES['userfile']['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            throw new RuntimeException('No file sent.');
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            throw new RuntimeException('Exceeded filesize limit.');
        default:
            throw new RuntimeException('Unknown errors.');
    }

    // You should also check filesize here.
    if ($_FILES['userfile']['size'] > 1000000) {
        throw new RuntimeException('Exceeded filesize limit.');
    }

    // DO NOT TRUST $_FILES['userfile']['mime'] VALUE !!
    // Check MIME Type by yourself.
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    if (false === $ext = array_search(
        $finfo->file($_FILES['userfile']['tmp_name']),
        array(
            'jpg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
        ),
        true
    )) {
        throw new RuntimeException('Invalid file format.');
    }

    // You should name it uniquely.
    // DO NOT USE $_FILES['userfile']['name'] WITHOUT ANY VALIDATION !!
    // On this example, obtain safe unique name from its binary data.
/*    if (!move_uploaded_file(
        $_FILES['userfile']['tmp_name'],
        sprintf('./uploads/%s.%s',
            sha1_file($_FILES['userfiluserfile']['tmp_name']),
            $ext
        )
    )) {
        throw new RuntimeException('Failed to move uploaded file.');
    }

    echo 'File is uploaded successfully.';
*/
/*} catch (RuntimeException $e) {

    echo $e->getMessage();

}

*/







    // Formular auswerten
    $active     = (!isset($_POST['active'])) ? "no" : "yes";
    //$imageType  = $_FILES['userfile']['type'] == "image/png" ? ".png" : ".jpg";
    $imageType  = ".jpg";

    // next free id
    $newId      = getFreeId("id_art","artikel");

    // insert int db
    $dbcon      = dbConnect(DBUSER,DBPW);
    $sql        = "insert into `artikel` (id_art,active, cat_id, name, description, price, anzahl, photo_orig, photo) values ";
    $sql       .= "(" . $newId . ",'" . $active . "'," . $_POST['cat'] . ",'" . $_POST['name'] . "','" . $_POST['desc'] . "',";
    $sql       .= $_POST['price'] . ",1,'" . $_POST['photo_orig'] . "','img/shop/" . $newId . $imageType . "')";
    $dbcon->query($sql);
    dbClose($dbcon);

    // Define Upload-Folder
    $uploaddir = '../img/shop/';
    $uploadfile = $uploaddir . $newId . $imageType;
/*
    if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
        echo "Datei ist valide und wurde erfolgreich hochgeladen.\n";
    } else {
        echo "Möglicherweise eine Dateiupload-Attacke!\n";
    }
*/
/*    echo '<pre>';
        print_r($_FILES);
        print_r($_POST);
    print "</pre>";
*/
    // Zurueck zum erfassen
    echo "</br></br><a href='?top=inventar&sub=shop' class='not_menu'>Zur&uuml;ck zum Erfassen</a>";

// Formular ausgeben
} else {

    // Formular-Definitionen
    $classFormFront = "formFront";
    $classFormSecond = "formSecond";

    // Falls abgeschickt: Inhalte sichern
    $nameValue          = isset($_POST['name']) ? $_POST['name'] : "";
    $catValue           = isset($_POST['cat']) ? $_POST['cat'] : "";
    $descValue          = isset($_POST['desc']) ? $_POST['desc'] : "";
    $priceValue         = isset($_POST['price']) ? $_POST['price'] : "";

    // Die Encoding-Art enctyoe MUSS wie dargestellt angegeben werden -->
    echo "<form enctype='multipart/form-data' action='?top=inventar&sub=" . $_GET['sub'] . "&action=add' method='POST'>";

    echo "<table width='450px'>";
            // Welcher Artikel
            echo "<tr>";
                echo "<td class='" . $classFormFront . "' valign='top'>Name</td>";
                echo "<td class='" . $classFormSecond . "'>";
                    echo "<input type='text' id='name' name='name' size='40' value='" . $nameValue . "' required />";
                echo "</td>";
            echo "</tr>";

            // Kategorie
            echo "<tr>";
                echo "<td class='" . $classFormFront . "' valign='top'>Kategorie</td>";
                echo "<td class='" . $classFormSecond . "'>";
                       echo "<select name='cat' id='cat'>";
                            echo "<option value='none'>--- Bitte ausw&auml;hlen ---</option>";
                            for ($i=0;$i<$catCount;$i++) {
                                echo "<option value='" . $catId[$i] . "'>" . $catName[$i] . "</option>";
                            }
                        echo "</select>";
                echo "</td>";
            echo "</tr>";
/*
            // Bild
            echo "<tr>";
                echo "<input type='hidden' name='MAX_FILE_SIZE' value='3000000000' />";
                echo "<td class='" . $classFormFront . "' valign='top'>Bild</td>";
                echo "<td class='" . $classFormSecond . "'>";
                    echo "<input name='userfile' type='file' />";
            echo "</td>";
            echo "</tr>";
*/
            // Welcher Artikel
            echo "<tr>";
                echo "<td class='" . $classFormFront . "' valign='top'>Original Photo</td>";
                echo "<td class='" . $classFormSecond . "'>";
                    echo "<input type='text' id='photo_orig' name='photo_orig' size='40' value=' ' required />";
                echo "</td>";
            echo "</tr>";
            
            // Aktiv/Inaktiv?
            echo "<tr>";
                echo "<td class='" . $classFormFront . "' valign='top'>Aktiv/Inaktiv</td>";
                echo "<td class='" . $classFormSecond . "'>";
                    echo "<input type='checkbox' name='active' id='active' /> Ja, Artikel im Shop ersichtlich!";
            echo "</td></tr>";

            // Beschreibung
            echo "<tr>";
                echo "<td class='" . $classFormFront . "' valign='top'>Beschreibung</td>";
                echo "<td class='" . $classFormSecond . "'>";
                    echo "<textarea name='desc' id='desc' rows='4' cols='30' value='" . $descValue . "'></textarea>";
                echo "</td>";
            echo "</tr>";

            // Preis
            echo "<tr>";
                echo "<td class='" . $classFormFront . "' valign='top'>Preis</td>";
                echo "<td class='" . $classFormSecond . "'>";
                    echo "<input type='text' id='price' name='price' size='40' value='" . $priceValue . "' required />";
                echo "</td>";
            echo "</tr>";

            // Submitbutton
            echo "<tr><td></td></tr>";
            echo "<tr><td colspan='2' style='text-align: right;'>";
                echo "<input type='submit' value='Artikel speichern' id='submit' name='submit' />";
            echo "</td></tr>";
        echo "</table>";


    echo "</form>";
}
?>
