<form action='index.php?top=home&action=send' method="POST">
<table border="1px solid red">
    <tr><td>
        <input name="user" id="user" type="text" />
    </td></tr>
    <tr><td>
        <input name="pw" id="pw" type="password" />
    </td></tr>
    <tr><td>
        <input name="send" id="send" type="submit" value="Login" />
    </td></tr>
</table>
</form>
