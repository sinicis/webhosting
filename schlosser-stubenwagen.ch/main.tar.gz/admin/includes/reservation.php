<?php

// check action
$action     = (!isset($_GET['confirm'])) && ( !isset($_GET['decline'])) ? "no" : "yes";
if ( $action == "yes" ) {
    $actionType = !isset($_GET['confirm']) ? "decline" : "confirm";
    $actionId   = !isset($_GET['confirm']) ? $_GET['decline'] : $_GET['confirm'];

    // do it
    adminAction("reservation",$actionId,$actionType);
}

// Titel
echo "<h1>Reservations-Vrwautig</h1>";

// Check if on subsite
$sub    = (!isset($_GET['sub'])) ? "" : $_GET['sub'];

// Show just what you need
showBooking($sub);


?>
