<h1>Dashboard<h1>

<table width='100%'>
    <tr><td>
        <h2>Bstellig&auml;</h2>
        <?php
        dashboard("bestellung","*","status","open","Bestellungen zu best&auml;tigen");
        dashboard("bestellung","*","status","confirmed","Bstellig&auml; zum vrschick&auml;");
        dashboard("bestellung","*","status","send","Bstellig&auml; wo no nid zauht si");
        ?>
    </td>
    <td valign='top'>
        <h2>Reservation&auml;</h2>
        <?
        dashboard("reservation","*","status","open","Reservationen zu best&auml;tigen");
        dashboard("reservation","*","status","ongoing","Stubew&auml;ge zurzyt vrmietet");
        ?>
    </td>
    </tr>
    <tr><td>
        <h2>Inventar</h2>
        <?php
/*
select distinct cat_id from artikel where active = "yes" and inventory != 0;
select id_art from artikel where inventory != 0
 select id_art from artikel where active = "yes" and inventory != 0
  */
        dashboard("artikel","id_art","inventory","1","Artikl&auml; im Lager");
        dashboard("artikel","id_art","active","yes' and inventory != '0","Artikl&auml; im Shop");
        dashboard("artikel","distinct cat_id","active","yes' and inventory != '0","verschidnigi Kategori&auml;");
        ?>
    </td>
    <td>
    </td>
    </tr>
</table>
