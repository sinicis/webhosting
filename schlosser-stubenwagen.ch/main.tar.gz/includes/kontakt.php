<h1>Kontakt</h1>

<table width="100%">
    <tr>
        <td valign='top'>
            <!-- Kontaktdaten Claudia -->
            Claudia Schlosser</br>
            <a href='mailto:info@schlosser-stubenwagen.ch' class='not_menu'>info@schlosser-stubenwagen.ch</a></br>
            +41 33 341 20 41</br></br>

            <b>Rechnungsadresse</b></br>
            Claudia Schlosser</br>
            H&ouml;henweg 21</br>
            3661 Uetendorf</br></br>

            <b>Abholadresse Stubenwagen</b></br>
            Schulhaus Burgiwil</br>
            3664 Burgistein</br>

        <td width='10px'></td>
        <td valign='top' text-align='right'>
            <!-- Bild von Claudia -->
            <img src='img/claudia.jpg' width='200px' />
        </td>
    </tr>
    <tr><td></br></td></tr>
    <tr>
        <td colspan='3'>
            <!-- Map von Schulhaus -->
            <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
            <div style="overflow:hidden;height:400px;width:600px;"><div id="gmap_canvas" style="height:400px;width:600px;"></div>
                <style>#gmap_canvas img{max-width:none!important;background:none!important;}</style>
            </div>
            <script type="text/javascript"> function init_map(){var myOptions = {zoom:15,center:new google.maps.LatLng(46.790414,7.513785399999961),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(46.790414, 7.513785399999961)});infowindow = new google.maps.InfoWindow({content:"<b>Schulhaus</b><br/>Burgiwil<br/>3664 Burgistein" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
        </td>
    </tr>
</table>

