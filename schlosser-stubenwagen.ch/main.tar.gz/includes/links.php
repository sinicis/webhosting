<h1>Links</h1>
<a href='http://www.babies-and-kids.ch' target="_blank" class='not_menu'><b>www.babies-and-kids.ch</b></a></br>
Fotografie für Schwanger Newborn Baby Kinder Familie</br></br>

<a href='http://herzlich.webnode.com' target="_blank" class='not_menu'><b>www.herzlich.webnode.com</b></a></br>
</i>herzlich</i> ist Ihre Adresse für das passende Geschenk. Für Babys und M&uuml;tter die gerne etwas Besonderes m&ouml;gen.</br>
