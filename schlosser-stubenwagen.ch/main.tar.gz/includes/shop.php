<?php
// Alle Kategorien auslesen
$result     = getCategory();
$catCount   = $result->num_rows;
$catSC      = array();
$catId      = array();
$catName    = array();
$catImg     = array();

// Fill up the arrays
while ( $row = $result->fetch_assoc() ) {
    array_push($catId,$row['id_cat']);
    array_push($catSC,$row['shortcut']);
    array_push($catName,$row['category']);
    array_push($catImg,$row['photo']);
}

// Alle Artikel auslesen
$result     = getArtikel("","","");
$artCount   = $result->num_rows;
$artId      = array();
$artName    = array();
$artDesc    = array();
$artPrice   = array();
$artImg     = array();

// Arrays fuellen
while ($row = $result->fetch_assoc()) {
    array_push($artId,$row['id_art']);
    array_push($artName,$row['name']);
    array_push($artDesc,$row['description']);
    array_push($artImg,$row['photo']);
    array_push($artPrice,$row['price']);
}

// ---------------------------------------
// Titel:
// ---------------------------------------
// a) wenn nichts gewaehlt
if ((!isset($_GET['buy'])) || (!in_array($_GET['buy'],$artId))) {
    if ((!isset($_GET['sub'])) || (!in_array($_GET['sub'],$catId))) {
        $title = "Shop";
// b) wenn Kategorie gewaehlt
    } else {
        $pos    = array_search($_GET['sub'],$catId);
        $title  = "Shop (<i>" . $catName[$pos] ."</i>)";
    }
// c) wenn Artikel gewaehlt
} else {
    $pos    = array_search($_GET['buy'],$artId);
    $title  = "Bestellung f&uuml;r <i>" . $artName[$pos] ."</i>";
}


// Titel ausgeben
echo "<h1>" . $title . "</h1>";
echo "<p>";

// wenn Stofftiere, dann Infos:
if ( !isset($_GET['sub']) ) {
    // chillout my friend and light a spliff :)
} elseif ( $_GET['sub'] == 1 ) {
    
    if (!isset($_GET['buy'])) {

        echo "Die lustigen Stofftiere kommen aus der Tilda Kollektion. Mit viel Liebe werden sie von Dora Gfeller hergestellt. ";
        echo "Bei den Giraffen, Elefanten und dem Hasen k&ouml;nnen Sie die Farben der Kleider auf Wunsch w&auml;hlen ";
        echo "(Im Bestellformular: Feld <i>Bemerkung</i>), das heisst in den rot, blau, grün, gelb, rosa, usw.. Tönen.</br></br>";

        echo "Lassen Sie sich überraschen, jedes dieser Tiere ist ein Einzelstück zum verlieben.</br></br>";

    }

    echo "<b>Hinweis:</b> Lieferfrist ca. 1 bis 2 Wochen";

// Wenn Stofftiere
} elseif ( $_GET['sub'] == 3 ) {
    echo "<b>Hinweis:</b> Lieferfrist ca. 1 bis 2 Wochen";
}

// ---------------------------------------
// Inhalt:
// ---------------------------------------

// nichts gewaehlt
if ((!isset($_GET['buy'])) || (!in_array($_GET['buy'],$artId))) {
    if ((!isset($_GET['sub'])) || (!in_array($_GET['sub'],$catId))) {
        echo "Sch&ouml;n haben Sie den Weg in meinen Shop gefunden. Zurzeit kann ich Ihnen insgesamt " . $artCount . " Artikel in " . $catCount ." verschiedenen Kategorien anbieten und hoffe, dass das Richtige f&uuml;r Sie dabei ist.</br></br>";

        echo "<table width='100%'>";
            echo "<tr>";

            for ($i=0;$i<$catCount;$i++) {

                echo "<td class='sw_overview' valign='top'>";
                    echo "<a class='not_menu' href='?top=shop&sub=" . $catId[$i]  . "'>";
                        echo "<img src='" . $catImg[$i] . "' width='180px'/></br>";
                        echo "<b>" . $catName[$i] . "</b></br></br>";
                    echo "</a>";
                echo "</td>";

                if ((($i + 1) % 3) == 0) {
                    echo "</tr><tr>";
                }
            } 
            echo "</tr>";
        echo "</table>";

// Kategorie gewaehlt
    } else {
        // Artikel ausgeben
        printArtikel($_GET['sub'],"","");
    }

// Artikel gewaehlt
} else {
    include('buy.php');
} // eo which page

?>
