<h1>Herzlich Willkommen</h1>

<p>
Sch&ouml;n haben Sie den Weg auf meine Website gefunden. Gerne biete ich Ihnen meine Dienstleistungen an. 
Ich w&uuml;rde mich sehr freuen, wenn ich Sie und Ihr Kind mit einem meiner Stubenwagen gl&uuml;cklich machen kann.

</br>
</br>

Der Tag aller Tage r&uuml;ckt immer wie n&auml;her und Ihnen fehlt noch das perfekte Bett f&uuml;r Ihren baldigen
Familienzuwachs? </br></br>

Kein Problem - Ich kann Ihnen helfen :)
</p>

<div class='homePictureLeftBottom' id='homePictureLeftBottom'>
    <img width='400px' src='img/front.png' />
</div>
