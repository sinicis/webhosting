<h1>&Uuml;ber mich</h1>

<?php  sendPdfMail("orderConfirmation",31,31,"bestellung");
?>

<table width='100%'>
    <tr>
    <td colspan='3'>
        Liebe Leserinnen und Leser,</br></br>
        Claudia Schlosser,</br>
        Ja, das ist mein Name, und ich bin eine interessante Dame…….</br>
        Wollen sie mehr erfahren &uuml;ber mein Wesen, dann habe ich hier was zum Lesen……</br></br>
    </td>
    </tr>
    <tr>
    <td>
        Einige interessante Dinge &uuml;ber mich:</br>
        <table width='100%'>
            <tr>
                <td align='center' width='20px' valign='top'>1.</td>
                <td>Ich habe vier Kinder geboren und bin wahnsinnig stolz darauf (1988 1990 1991 1994)</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>2.</td>
                <td>Ich könnte nie in der Stadt leben</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>3.</td>
                <td>Ich habe eine Liste mit 100 Dingen die ich im Leben noch machen werde</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>4.</td>
                <td>Ich liebe windiges Wetter, am besten noch mit Sturmböen, Sonne und Regen, herrlich anregend</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>5.</td>
                <td>Zuhören kann ich gut, reden auch</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>6.</td>
                <td>Lieber bepacke ich mich endlos, als einen Weg zweimal zu gehen</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>7.</td>
                <td>Ich bin neugierig, gründlich, manchmal perfektionistisch, dann wieder locker, entspannt, kreativ</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>8.</td>
                <td>Manchmal wenn der Arbeitstag besonders gut gelaufen ist, habe ich ziemliche Höhenflüge, bzw. vorübergehende Tendenzen zum Grössenwahnsinn</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>9.</td>
                <td>Ich gebe mir ein Trinkgeld und gönne mir etwas davon</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>10.</td>
                <td>Je älter ich werde, desto mehr Seiten von Mutter und Vater entdecke ich von mir. (Nicht immer spassig!)</td>
            </tr>
        </table>
        </br>
        
        Einige uninteressante Dinge über mich:</br>
        <table width='100%'>
            <tr>
                <td align='center' width='20px' valign='top'>1.</td>
                <td>Meine Haare fangen an grau zu werden</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>2.</td>
                <td>Ich gehe immer zu spät ins Bett</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>3.</td>
                <td>Meistens arbeite ich an mehreren Projekten gleichzeitig</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>4.</td>
                <td>Ich bin George Cloonys Kaffewerbung auf den Leim gegangen</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>5.</td>
                <td>Die Tageszeitung lese ich von hinten nach vorne</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>6.</td>
                <td>Meistens schaffe ich nicht alles was ich mir vorgenommen habe</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>7.</td>
                <td>Ich mag es über mein Smartphone zu wischen</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>8.</td>
                <td>Am PC zu spielen halte ich für vertane Zeit; trotzdem tue ich es ab und zu</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>9.</td>
                <td>Ich mag die Hitze des Sommers nicht</td>
            </tr>
            <tr>
                <td align='center' width='20px' valign='top'>10.</td>
                <td>Ich hatte eine Bilderbuchkindheit </td>
            </tr>
        </table>
    </td>
    
    <!-- Bild von Claudia -->
    <td width='10px'> </td>
    <td valign='top'>
        <img src='img/claudia.jpg' width='200px' />
    </td>
    </tr>
</table>
<?php //calcNextFree(16); ?>
