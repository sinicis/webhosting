<?php

function displayMenuPoint($page,$activePage,$text) {

	if ($page == $activePage) { ?>
		<div class='menupointActive'><?=$text?></div>
	<? } else { ?>
		<div class='menupoint'><a href='?top=<?=$page?>'><?=$text?></a></div>
	<? }

} // end of function displayMenuPoint

function displayMenu() {
?>
	<div id="menu" class="menu"> 
		<div class='menupointBlank'></div>
		<?
	
		$activePage = isset($_GET['top']) ? $_GET['top'] : "home";
		displayMenuPoint("home",$activePage,"Startseite");
		displayMenuPoint("we",$activePage,"&Uuml;ber uns");
		displayMenuPoint("wagen",$activePage,"Stubenwagen");
		displayMenuPoint("zubehoer",$activePage,"Zubeh&ouml;r");
		displayMenuPoint("info",$activePage,"Informationen");	
		displayMenuPoint("download",$activePage,"Downloads");		
		displayMenuPoint("kontakt",$activePage,"Kontakt");		
	
	?></div>
<?
} // end of function displayMenu

function displayPage($activePage) {

	$legalPages = array("home","firma","hochbau","anumbau","kontakt");
	if ( in_array($activePage,$legalPages )) {
		include("includes/$activePage.php");
	} else {
		die;
	}

} // end of function displayPage



?>
