<!doctype html>
<html lang="de">
	<head>

	
	  <meta charset="utf-8">
	
	  <title>Stubenwagen-Vermietung Berner Oberland</title>
	  <meta name="description" content="Stubenwagen-Vermietung Berner Oberland">
	  <meta name="author" content="Simon Isenschmid">
	
	  <link rel="stylesheet" href="css/style.css">
	
	  <!--[if lt IE 9]>
	  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	  <![endif]-->
  
	  
	  
	</head>

	<body>
	<div id="mainWrapper" class="mainWrapper">
		<!--<div id="wrapper" class="wrapper">-->
		
			<div id="header" class="header">
				<center>
				<!--<img src='images/logo.jpg' width='600x' />-->
				Stubenwagen-Vermietung Berner Oberland
				</center>
			</div>

			<div id="subheader" class="subheader">
				Der zuverl&auml;ssige Partner mit grossem Interesse am Wohl Ihres Kindes - Nur wer gut schl&auml;ft, wird einmal gross und stark....
			</div>

			<div id="contentWrapper" class="contentWrapper">
			
				
				<div id="menu">
					<div class='menupointBlank'></div>
					<div class='menupoint'></div>					
					<div class='menupoint'></div>
					<div class='menupoint'></div>
					<div class='menupoint'></div>
					<div class='menupoint'></div>
					<div class='menupoint'></div>
				</div>
				
					<div class="contentRightWrapper">
				
					<div id="breadcrumps" class="breadcrumps">
						<!-- Startseite / <a href="index_alt.php" class="not_menu">Stubenwagen</a> -->
					</div>
					
					<div id="content" class="content">
					
						<h1>Website in Entwicklung (Aufschaltung Januar 2015)</h1>
					
						Zurzeit wird mit Hochdruck an unserer Website gearbeitet und wir m&ouml;chten Sie noch um etwas Geduld bitten 
						bis wir Ihnen unser Stubenwagen-Sortiment pr&auml;sentieren
						</br></br>
						<center>
							<img src="img/frau.jpg" width="300px" />
							
						</center>
						</br></br>
						Sie k&ouml;nnen uns aber bereits jetzt via <a href="mailto:info@schlosser-stubenwagen.ch">info@schlosser-stubenwagen.ch</a> kontaktieren.
								
					</div>
				</div>

			</div>
			
			<div class="footerOutline">
				<div id="footer" class="footer">
					
				</div>
			</div>
		<!--</div>-->
		
		</div>
		
		<!-- download it! html boilerplate; and reset till... -->
		
	</body>
</html>
