<?php


// Include Admin Functions
if ( substr( $_SERVER['REQUEST_URI'], 0, 10 ) == "/dev/admin" ) {
    include('/home/ironsmit/sec-data/schlosser-stubenwagen.ch/.adminFunctions.php');
}

##########################################
#                                        #
#              LOGIN/LOGOUT              #
#                                        #
##########################################

function checkLogin($user,$pw) {
    
    if (($pw == ADMPW) && ($user == ADMUSER)) {
        $_SESSION['state'] = "loggedin";
        $_SESSION['user'] = $user;

    } else {
        // thinkabout!
    }
}

function logout() {

    session_unset();
    session_destroy();

    session_start();
    $_SESSION['state'] = 'fuckoff';

} // eof logout


##########################################
#                                        #
#                DATABASE                #
#                                        #
##########################################

function dbConnect($user,$pw) {

	$host 	= 'localhost';

	$dbcon 	= new mysqli($host,$user,$pw,DBNAME);

    if($dbcon->connect_errno > 0){
        die('Verbindungsfehler: ' . $db->connect_erro );
    }

	return $dbcon;
             
} // eof dbConnect

function dbClose($dbcon) {

    $dbcon->close();
    
} // eof dbClose 

##########################################
#                                        #
#                  MENU                  #
#                                        #
##########################################

function displayMenuPoint($page,$activePage,$activeSub,$text,$level) {

    // check if top or sub
    $class 	= $level == "top" ? "menupoint" : "subMenupoint";
    $link	= $level == "top" ? "?top=$page" : "?top=$activePage&sub=$page";

    // add menu to link
    $link   = !isset($_GET['menu']) ? $link : $link . "&menu=" . $_GET['menu'];

    if (( $page == $activePage) || ( $page == $activeSub )) { 
        echo "<div class='" . $class . "Active'><a href='" . $link . "'>" . $text . "</a></div>";
    } else { 
        echo "<div class='" . $class . "'><a href='" . $link . "'>" . $text . "</a></div>";
    }

} // end of function displayMenuPoint

function displayMenu($area) {

    // get current page
    $activePage 	= isset($_GET['top']) ? $_GET['top'] : "home";
    $activeSub 		= isset($_GET['sub']) ? $_GET['sub'] : "none";

    # Menu for UI
    if ($area == "ui") {
        displayMenuPoint("home",$activePage,$activeSub,"Startseite","top");
        displayMenuPoint("me",$activePage,$activeSub,"&Uuml;ber mich","top");
        displayMenuPoint("wagen",$activePage,$activeSub,"Stubenwagen","top");
            if ( $activePage == "wagen") {
                displaySubMenu($activePage,$activeSub);
            } // end of submenu-points
        displayMenuPoint("shop",$activePage,$activeSub,"Zubeh&ouml;r (Shop)","top");
            if ( $activePage == "shop") {
                displaySubMenu($activePage,$activeSub);
            } // end of submenu-points
        displayMenuPoint("info",$activePage,$activeSub,"Mietpreise / Infos","top");	
            if ( $activePage == "info") {
                displaySubMenu($activePage,$activeSub);
            }
        //displayMenuPoint("download",$activePage,$activeSub,"Downloads","top");		
        displayMenuPoint("links",$activePage,$activeSub,"Links","top");		
        displayMenuPoint("kontakt",$activePage,$activeSub,"Kontakt","top");		
        
    # Admin-Menu
    } elseif ($area == "admin") {

        # Check if logged in
        if ( $_SESSION['state'] == "loggedin" ) {

            displayMenuPoint("dash",$activePage,$activeSub,"Dashboard","top");	
            displayMenuPoint("events",$activePage,$activeSub,"N&auml;chste Ereignisse","top");		
            displayMenuPoint("bestellung",$activePage,$activeSub,"Bstelligä","top");		
            if ( $activePage == "bestellung") {
                displaySubMenu($activePage,$activeSub);
            } // end of submenu-points
            displayMenuPoint("reservation",$activePage,$activeSub,"Reservation&auml;","top");		
            if ( $activePage == "reservation") {
                displaySubMenu($activePage,$activeSub);
            } // end of submenu-points
            displayMenuPoint("wagen",$activePage,$activeSub,"Stubenwagen","top");		
            displayMenuPoint("shop",$activePage,$activeSub,"Zubeh&ouml;r (Shop)","top");		
            if ( $activePage == "shop") {
                displaySubMenu($activePage,$activeSub);
            } // end of submenu-points
            displayMenuPoint("stats",$activePage,$activeSub,"Statistiken","top");		
            displayMenuPoint("home&action=logout",$activePage,$activeSub,"Logout","top");

        } // eoi loggedin

    } //eow menu

} // end of function displayMenu

function displaySubMenu($activePage,$activeSub) {

    $area = substr( $_SERVER['REQUEST_URI'], 0, 10 ) == "/dev/admin" ? "admin" : "user";

	// Stubenwagen
	if ( $activePage == "wagen" ) {

        // generate link
        $link	= !isset($_GET['sub']) ? "?top=$activePage" : "?top=$activePage&sub=$activeSub";

        // show menupoint
        if (( !isset($_GET['menu'])) || ( $_GET['menu'] == 'show' ) ) {
            echo "<div class='subMenupoint'><a href='" . $link . "&menu=hide'><i>Flotte ausblenden</i></a></div>";
        } else {
            echo "<div class='subMenupoint'><a href='" . $link . "&menu=show'><i>Flotte einblenden</i></a></div>";
        }

        if ((!isset($_GET['menu'])) || ( $_GET['menu'] == "show")) {
        
            // Alle Wagen aus DB:
            $sql    = "select id_sw, name from `stubenwagen` where active = 'yes' order by size_id";
            $dbcon  = dbConnect(DBUSER,DBPW);
            $result = $dbcon->query($sql);
            dbClose($dbcon);

            // displaying the points
            while ($row = $result->fetch_assoc()){
                displayMenuPoint($row['id_sw'],$activePage,$activeSub,$row['name'],"sub");
            }

        } // eoi show wagen

	// Zubehör
	} elseif ( $activePage == "shop" ) {

        $result = getCategory();

        // displaying the points
        while ($row = $result->fetch_assoc()){
		    displayMenuPoint($row['id_cat'],$activePage,$activeSub,$row['category'],"sub");
	    }

    // Bestellungen
	} elseif ( $activePage == "bestellung" ) {
		displayMenuPoint("open",$activePage,$activeSub,"N&ouml;ii Bstellig&auml;","sub");
		displayMenuPoint("confirmed",$activePage,$activeSub,"Offnegi Bstellig&auml;","sub");
		displayMenuPoint("declined",$activePage,$activeSub,"Abglehnti Bstellig&auml;","sub");
		displayMenuPoint("send",$activePage,$activeSub,"Noni zauhti Bstellig&auml;","sub");
		displayMenuPoint("closed",$activePage,$activeSub,"Fertigi Bstellig&auml;","sub");

    // Reservationen
	} elseif ( $activePage == "reservation" ) {
		displayMenuPoint("open",$activePage,$activeSub,"N&ouml;ii Reservation&auml;","sub");
		displayMenuPoint("declined",$activePage,$activeSub,"Abglehnti Reservation&auml;","sub");
		displayMenuPoint("oncoing",$activePage,$activeSub,"Momentan vrmietet","sub");
		displayMenuPoint("comingsoon",$activePage,$activeSub,"Gli vrmietet","sub");
		displayMenuPoint("closed",$activePage,$activeSub,"Abglofnegi Mietin&auml;","sub");

    } elseif ( $activePage == "wagen" ) {
		displayMenuPoint("wagen_ov",$activePage,$activeSub,"&Uuml;bersicht","sub");
		displayMenuPoint("wagen_neu",$activePage,$activeSub,"Neuen Wagen erfassen","sub");

    } elseif ( $activePage == "info" ) {
		displayMenuPoint("wageni",$activePage,$activeSub,"Stubew&auml;ge","sub");
		displayMenuPoint("shopi",$activePage,$activeSub,"Zuebeh&ouml;r (Shop)","sub");

    } elseif ( $activePage == "shop" ) {
		displayMenuPoint("shop_ov",$activePage,$activeSub,"&Uuml;bersicht","sub");
		displayMenuPoint("shop_neu",$activePage,$activeSub,"Neuen Wagen erfassen","sub");
		displayMenuPoint("shop_cat",$activePage,$activeSub,"Kategorien verwalten","sub");
    }

} // end of function displayMenu

function displayPage($area,$activePage) {


	if ($area == "ui") { 
        $legalPages = array("home","me","wagen","shop","info","download","links","kontakt");
	} elseif ($area == "admin") {
        $legalPages = array("login","dash","events","bestellung","reservation","reserv_neu","reserv_aktuell","reserv_alt","wagen","wagen_ov","wagen_neu","shop","shop_ov","shop_neu","shop_cat");

        // check if login-window
        if (($activePage == "home") && ($_SESSION['state'] != "loggedin")) {
            $activePage = "login";
        //} else {
          //  $activePage = ((isset($_GET['sub'])) && (is_string($_GET['sub']))) ? $_GET['sub'] : $_GET['top'];
        } // eoi loggeind
    } //eow area

    // check if legal
    if ( in_array($activePage,$legalPages )) {
		include("includes/$activePage.php");
	} else {
		die;
	}

} // end of function displayPage


##########################################
#                                        #
#              STUBENWAGEN               #
#                                        #
##########################################

function getWInfos($id) {

    $dbcon  = dbConnect(DBUSER,DBPW);
    $sql    = "select * from `stubenwagen` where id_sw = " . $id;
    $result = $dbcon->query($sql);
    dbClose($dbcon);
    
    return $result;

} // eof getWInfos()

function printWInfos($infos) {

    $tdClassFront   = "sw_detail_front";
    $tdClassSecond  = "sw_detail_second";

    echo "<table width='100%'>";
        echo "<tr><td class='top' id='top'>";
            echo "<b>Eigenschaft</b>";
        echo "<td class='top' id='top'>";
            echo "<b>Beschreibung</b>";
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Korbform" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo $infos['korb'];
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Vorhang" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo $infos['vorhang'];
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Innenausstattung" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo $infos['innen'];
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Fixleint&uuml;cher" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo $infos['leintuch'];
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Duvet" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo "Duvet clean junior (synthetisch, waschbar bei 95&deg; Celsius)</br>Gewicht: 200g";
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Duvetbez&uuml;ge" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo $infos['duvet'];
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Matratze" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo $infos['matratze'];
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Kopfspuckt&uuml;cher" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo $infos['kopfspuck'];
        echo "</td></tr>";
        echo "<tr><td class=" . $tdClassFront . " id=" . $tdClassFront . " valign='top'>";
            echo "Zusatzinfos" . "</td><td class=" . $tdClassSecond . " id=" . $tdClassSecond . ">";
            echo $infos['description'];
        echo "</td></tr>";
    echo "</table>";

} // eof printWInfos

function checkFavs() {

    if ($_SESSION['favCount'] == 0) {
        $favCount = $_SESSION['favCount'];
        for ($i=0;$i<6;$i++) {
            $favCount = $_SESSION['favs'][$i] != "-" ? ($favCount+1) : $favCount;
        }
        // reset SESSION-Var if needed
        $_SESSION['favCount'] = $favCount;
    } // if no favs selected

} // eof checkFavs

function printFavs() {

    echo "<table width='100%'>";
        echo "<tr>";
            echo "<td width='60px'>";
                if ($_SESSION['favs'][0] != "-") {
                    $result = getWInfos($_SESSION['favs'][0]);
                    $row    = $result->fetch_assoc();
                    $img    = $row['mainphoto'];
                    $id     = $row['id_sw'];
                    
                    echo "<a href='?top=wagen&sub=" . $id . "'>";
                        echo "<img src='" . $img . "' width='60px'>";
                    echo "</a>";
                }   
            echo "</td>";
            echo "<td width='60px'>";
                if ($_SESSION['favs'][1] != "-") {
                    $result = getWInfos($_SESSION['favs'][1]);
                    $row    = $result->fetch_assoc();
                    $img    = $row['mainphoto'];
                    $id     = $row['id_sw'];
                    
                    echo "<a href='?top=wagen&sub=" . $id . "'>";
                        echo "<img src='" . $img . "' width='60px'>";
                    echo "</a>";
                }   
            echo "</td>";

            echo "<td width='60px'>";
                if ($_SESSION['favs'][2] != "-") {
                    $result = getWInfos($_SESSION['favs'][2]);
                    $row    = $result->fetch_assoc();
                    $img    = $row['mainphoto'];
                    $id     = $row['id_sw'];
                    
                    echo "<a href='?top=wagen&sub=" . $id . "'>";
                        echo "<img src='" . $img . "' width='60px'>";
                    echo "</a>";
                }   
            echo "</td>";
        echo "</tr><tr>";
            echo "<td width='60px'>";
                if ($_SESSION['favs'][3] != "-") {
                    $result = getWInfos($_SESSION['favs'][3]);
                    $row    = $result->fetch_assoc();
                    $img    = $row['mainphoto'];
                    $id     = $row['id_sw'];
                    
                    echo "<a href='?top=wagen&sub=" . $id . "'>";
                        echo "<img src='" . $img . "' width='60px'>";
                    echo "</a>";
                }   
            echo "</td>";

            echo "<td width='60px'>";
                if ($_SESSION['favs'][4] != "-") {
                    $result = getWInfos($_SESSION['favs'][4]);
                    $row    = $result->fetch_assoc();
                    $img    = $row['mainphoto'];
                    $id     = $row['id_sw'];
                    
                    echo "<a href='?top=wagen&sub=" . $id . "'>";
                        echo "<img src='" . $img . "' width='60px'>";
                    echo "</a>";
                }   
            echo "</td>";

            echo "<td width='60px'>";
                if ($_SESSION['favs'][5] != "-") {
                    $result = getWInfos($_SESSION['favs'][5]);
                    $row    = $result->fetch_assoc();
                    $img    = $row['mainphoto'];
                    $id     = $row['id_sw'];
                    
                    echo "<a href='?top=wagen&sub=" . $id . "'>";
                        echo "<img src='" . $img . "' width='60px'>";
                    echo "</a>";
                }   
            echo "</td>";
        echo "</tr>";
    echo "</table>";

} // eof printFavs() 

function getCategory() {

		// Alle Kategorien aus DB:
        $sql    = "select * from `category`";
        $dbcon  = dbConnect(DBUSER,DBPW);
        $result = $dbcon->query($sql);
        dbClose($dbcon);

        return($result);

} // eof getCategory()

function getInvCount($artId) {

		// Alle Artikel aus DB:
        $sql    = "select inventory from `artikel` where `id_art` = " . $artId;
        $dbcon  = dbConnect(DBUSER,DBPW);
        $result = $dbcon->query($sql);
        dbClose($dbcon);

        $row        = $result->fetch_assoc();
        $invCount   = $row['inventory'];

        return($invCount);

} // eof getInvCount()

function setInvCount($artId,$invCount) {

		// Alle Artikel aus DB:
        $sql    = "update artikel set inventory = " . $invCount . " where id_art=" . $artId;
        $dbcon  = dbConnect(DBUSER,DBPW);
        $result = $dbcon->query($sql);
        dbClose($dbcon);

} // eof setInvCount()



function getArtikel($catId,$chosenArtId,$rule) {

        // Condition definieren
        $condition = $catId == "" ? "where `active` = 'yes'" : "where `cat_id` = $catId and `active`= 'yes'";
        $condition = $rule == "showalways" ? $condition : $condition . " and `inventory` != 0";
        $condition = $chosenArtId == "" ? $condition : $condition . " and `id_art` = " . $chosenArtId;

		// Alle Artikel aus DB:
        $sql    = "select * from `artikel` " . $condition;
        $dbcon  = dbConnect(DBUSER,DBPW);
        $result = $dbcon->query($sql);
        dbClose($dbcon);

        return($result);

} // eof getArtikel()

function printArtikel($catId,$chosenArtId,$rule) {

    // Arrays definieren
    $artId      = array();
    $artName    = array();
    $artDesc    = array();
    $artSize    = array();
    $artImg     = array();
    $artPrice   = array();

    // Artikel auslesen
    $result     = getArtikel($catId,$chosenArtId,$rule);

    // Anzahl
    $artCount   = $result->num_rows;

    // Arrays fuellen
    while ($row = $result->fetch_assoc()) {
        array_push($artId,$row['id_art']);
        array_push($artName,$row['name']);
        array_push($artDesc,$row['description']);
        array_push($artSize,$row['size']);
        array_push($artImg,$row['photo']);
        array_push($artPrice,$row['price']);
    }

    // Artikel ausgeben
    $tdClassFront   = "sw_detail_front";
    $tdClassSecond  = "sw_detail_second";

    echo "<table width='100%' class='artikelWrapper' id='artikelWrapper'>";
        for ($i=0;$i<$artCount;$i++) {
            echo "<tr>";
                echo "<td>";
                    if ( $chosenArtId == "" ) {
                        echo "<b>" . $artName[$i] . "</b></br></br>";
                    }
                    echo "<table class='artikel' id='artikel' width='550px'>";
                        echo "<tr>";
                            echo "<td class='artikelImg'>";
                                echo "<img src='" . $artImg[$i] . "' width='180px'/></br>";
                            echo "</td>";
                            echo "<td valign='top'>";
                                echo "<table class='artikelDesc' width='400px'>";
                                    echo "<tr>";
                                        echo "<td class='top'>Eigenschaft</td>";
                                        echo "<td class='top'>Beschreibung</td>";
                                    echo "</tr>";
                                    echo "<tr>";
                                        echo "<td valign='top' class='" . $tdClassFront . "'>";
                                            echo "Beschreibung:";
                                        echo "</td>";
                                        echo "<td valign='top' class='" . $tdClassSecond . "'>";
                                            echo $artDesc[$i];
                                        echo "</td>";
                                    echo "</tr>";
                                    
                                    // Groesse nur bei Stofftieren anzeigen
                                    if ( $catId == 1 ) {
                                        echo "<tr>";
                                            echo "<td valign='top' class='" . $tdClassFront . "'>";
                                                echo "Gr&ouml;sse:";
                                            echo "</td>";
                                            echo "<td valign='top' class='" . $tdClassSecond . "'>";
                                                echo $artSize[$i];
                                            echo "</td>";
                                        echo "</tr>";
                                    } // end of if groesse anzeigen

                                    echo "<tr valign='top'>";
                                        echo "<td valign='top' class='" . $tdClassFront . "'>";
                                            echo "Preis:";
                                        echo "</td>";
                                        echo "<td valign='top' class='" . $tdClassSecond . "'>";
                                            echo $artPrice[$i] . " CHF";
                                        echo "</td>";
                                    echo "</tr>";
                                    echo "<tr><td>";
                                        echo "</br>";
                                    echo "</td></tr>";
                                    echo "<tr>";
                                        echo "<td colspan='2' class='containButton' id='containButton'>";
                                            if ( $chosenArtId == "" ) {
                                                // Action-Button 
                                                actionButton("right","?top=shop&sub=" . $_GET['sub'] . "&buy=" . $artId[$i],"Jetzt bestellen!");
                                            }
                                        echo "</td>";
                                    echo "</tr>";
                                echo "</table>";
                            echo "</td>";
                        echo "</tr>";
                    echo "</table>";
                    echo "</br></br>";
                echo "</td>";
            echo "</tr>";
        } 
    echo "</table>";


} // eof printArtikel()

function sendAdminMail($type) {

    // Include Admin Functions
    if ( substr( $_SERVER['REQUEST_URI'], 0, 5 ) == "/dev/" ) {
        $to         = "simon@ironsmith.ch";
    } else {
        $to         = "info@schlosser-stubenwagen.ch";
    }

    // Wenn neue Bestellung
    if ($type == "bestellung" ) {

        $subject    = "Neue Bestellung";
        $message    = "Salut Claudia</br></br>";
        $message   .= "Yeeeeeeeeah da het &ouml;per &ouml;pis bsteut u wotnis ds Portemonnaie f&uuml;u&auml;e! :D<br><br>";
        $message   .= "H&auml;b &auml; guet&auml; Tag!";

    // Wenn neue Reservation
    } elseif ($type == "reservation") {

        $subject    = "Neue Reservation";
        $message    = "Salut Claudia<br><br>";
        $message   .= "Yeeeeeeeeah da het &ouml;per &auml; Stubewage reserviert... Money, Money, Money! :D<br><br>";
        $message   .= "H&auml;b &auml; guet&auml; Tag!";
    }

    // Default-Headers
    $headers = 'From: webshop@schlosser-stubenwagen.ch' . "\r\n" .
        'Reply-To: info@schlosser-stubenwagen.ch' . "\r\n" .
        'Content-type: text/html; charset=iso-8859-1' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();

    // Mail senden
    mail($to, $subject, $message, $headers);

} // eof sendAdminMail

// Function sendPdfMail
function sendPdfMail($type,$id,$idArt,$table) {

    // important variables
    $_SESSION['type'] = $type;
    $_SESSION['id'] = $id;
    $_SESSION['idArt'] = $idArt;
    $_SESSION['table'] = $table;

    // get the HTML
    ob_start();
    include('includes/pdf_templates/order.php');
    $content = ob_get_clean();

    // convert to PDF
    require_once('library/html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','de',true,'UTF-8',array(20, 20, 20, 20));
        $html2pdf->pdf->SetDisplayMode('fullpage');
//      $html2pdf->pdf->SetProtection(array('print'), 'spipu');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $html2pdf->Output('Bestellbestaetigung_Schlosser-Stubewagen.pdf',"F");
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

} // end of sendPdfMail

function getFreeId($field,$table) {

    $dbcon  = dbConnect(DBUSER,DBPW);
    $sql    = "select max($field) as highestId from $table";
    $result = $dbcon->query($sql);
    dbClose($dbcon);

    $row    = $result->fetch_assoc();
    $freeId = $row['highestId'] + 1;

    return $freeId;

} // eof getFreeId

function actionButton($side,$link,$text) {

    $divClass   = $side == "left" ? "actionLeft" : "actionRight";

    echo "<a href='" . $link . "' class='not_menu'>";
        echo "<div class='" . $divClass . "' id='" . $divClass . "'>";
            echo "<table width='100%'>";
                echo "<tr>";
                    if ( $side == "left" ) {
                        echo "<td style='line-height:0'>";
                            echo "<img src='img/arrowLeft.png' />";
                        echo "</td>";
                    }
                    echo "<td valign='center'>";
                        echo "<b>" . $text . "</b>";
                    echo "</td>";
                    if ( $side == "right" ) {
                        echo "<td style='line-height:0'>";
                            echo "<img src='img/arrowRight.png' />";
                        echo "</td>";
                    }
                echo "</tr>";
            echo "</table>";
        echo "</div>";
    echo "</a>";

} // eof actionButton

function calcNextFree($id) {

    // get date
    $today      = date("Y-m-d");
    $nextfree   = "unset";

    // get all reservation out of database and then start calculation
    $dbcon  = dbConnect(DBUSER,DBPW);
    $sql    = "select startdate_sys, enddate_sys from reservation where sw_id=$id";
    $result = $dbcon->query($sql);
    dbClose($dbcon);

    // if empty
    $resCount   = $result->num_rows;
    if ($resCount == 0 ) {
        $nextfree = "now";
    } else {

        // make arrays and fill
        $startdate  = array();
        $enddate    = array();
        while ( $row = $result->fetch_assoc() ) {
            array_push($startdate,$row['startdate_sys']);
            array_push($enddate,$row['enddate_sys']);
        }

        // first check if available asap
        if ( $startdate[0] > date('Y-m-d', strtotime("+3 months 2 weeks")) ) {
            $nextfree = "now";
        } elseif ( $resCount == 1 ) {
            $nextfree    = date('d.m.Y', strtotime("+2 weeks", strtotime($enddate[0])));
        } else {

            // check each date
            for ( $i=0; $i<$resCount; $i++ ) {
                if ( $enddate[$i] > date('Y-m-d', strtotime("+3 months 2 weeks", strtotime($startdate[$i+1]))) ) {

                    // calculate the nextfree-date
                    $nextfree           = date('d.m.Y', strtotime("+2 weeks", strtotime($enddate[$i])));

                    // set $i to $rescount
                    $i  = $resCount;

                } // eoi nextfree defined

            } // end of checking each reservation

            // set nextfree if still not defined
            if ( $nextfree == "unset" ) {
                $nextfree     = date('d.m.Y', strtotime("+2 weeks", strtotime($enddate[$resCount-1])));
            } // eo set it now

        } // end of asap available

    } // eoi empty

    // update database
    $dbcon  = dbConnect(DBUSER,DBPW);
    $sql    = "update stubenwagen set nextfree = '" . $nextfree . "' where id_sw=" . $id;
    $result = $dbcon->query($sql);
    dbClose($dbcon);

} // eof calcNextFree


?>
